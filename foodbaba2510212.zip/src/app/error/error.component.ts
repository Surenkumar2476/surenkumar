import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-error',
  templateUrl: './error.component.html',
  styleUrls: ['./error.component.css']
})
export class ErrorComponent implements OnInit {  
   
  output:any="";
  myvalue:any='';
  constructor() { }

  ngOnInit(): void {
  }

  calculate(amount:any,time:any,interest:any){
     this.output=((amount*time*interest)/100);
     console.log(this.output);
  }

  list(val:any){
     if(val=="1")
     {
       this.myvalue=7;
     }
     else if(val=="2"){
       this.myvalue=8;

     }
     else if(val=="3")
     {
       this.myvalue=12;
     }
     if(val=="4")
     {
       this.myvalue=10;
     }     
  }



}
