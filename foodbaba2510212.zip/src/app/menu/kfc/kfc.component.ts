import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-kfc',
  templateUrl: './kfc.component.html',
  styleUrls: ['./kfc.component.css']
})
export class KfcComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
